import * as i0 from "@angular/core";
import { EventEmitter } from "@angular/core";
export declare class HalloweenUi {
  static ɵfac: i0.ɵɵFactoryDeclaration<HalloweenUi, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<HalloweenUi, "lib-halloween-ui", never, {}, {}, never, never, true, never>;
}
export declare class MonsterCardComponent {
  eyebrow: string;
  image: string;
  imageAlt: string;
  title: string;
  text: string;
  buttonLabel: string;
  tone: 'blood' | 'silver';
  action: EventEmitter<void>;
  static ɵfac: i0.ɵɵFactoryDeclaration<MonsterCardComponent, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<MonsterCardComponent, "lib-monster-card", never, {
    "eyebrow": {
      "alias": "eyebrow";
      "required": false;
    };
    "image": {
      "alias": "image";
      "required": false;
    };
    "imageAlt": {
      "alias": "imageAlt";
      "required": false;
    };
    "title": {
      "alias": "title";
      "required": false;
    };
    "text": {
      "alias": "text";
      "required": false;
    };
    "buttonLabel": {
      "alias": "buttonLabel";
      "required": false;
    };
    "tone": {
      "alias": "tone";
      "required": false;
    };
  }, {
    "action": "action";
  }, never, never, true, never>;
}